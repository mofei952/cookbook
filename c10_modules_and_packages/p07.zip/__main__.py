import spam


spam.bar()

def bar():
    print('bar')

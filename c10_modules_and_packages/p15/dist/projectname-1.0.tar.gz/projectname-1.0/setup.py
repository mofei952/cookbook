from distutils.core import setup


setup(
    name='projectname',
    version='1.0',
    authot='mofei',
    author_email='xiangjingbo@126.com',
    url='http://www.xx.com/projectname',
    packages=['projectname']
)

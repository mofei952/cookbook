def foo():
    print('hello')
